<?php
/*
 Página de error.
 */
?>
<h1>Error 404</h1>
<p style='background: #ff9999; border-radius: 5px; padding:2em; margin:1em'>
    Recurso no encontrado
</p>
<p>No existe el fichero: <?=$file?></p>

