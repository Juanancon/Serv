<!-- Me falta darle apariencia, en estilos css lo tengo -->
<div class="container" id="menu">

    <a href='?ctrl=ctr_lista'><input class="btn btn-warning" type="button"  value ="Mostrar Ofertas"></input></a>
    <a href='?ctrl=ctr_alta'><input class="btn btn-warning" type="button"  value ="Nueva Oferta"></input></a>

</div>