<footer>
    <div class="navbar navbar-light navbar-fixed-bottom">
        <div class="container">
            <p class="navbar-text pull-left">© 2016 - Site Built By Juan Antonio Núñez
            </p>
        </div>
    </div>
</footer>

