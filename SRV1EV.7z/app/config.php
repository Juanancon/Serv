<?php
$db_conf = array(
    "servidor"=>"localhost",
    "usuario"=>"root",
    "password"=>"",
    "base_datos"=>"Juanito");