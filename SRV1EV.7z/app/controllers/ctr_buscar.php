<?php
include (HELPERS_PATH.'filtrado.php');
include (HELPERS_PATH. 'helper.php');
include (MODELS_PATH . 'bda_ofertasmodelo.php');
include (MODELS_PATH . 'bda_select.php');

include_once (VIEWS_PATH . 'view_busqueda.php');