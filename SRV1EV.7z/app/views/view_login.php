<div class="container">
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
        <br />
        <form method="post">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h1>Login</h1>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <div class="input-group">
                                <span class="input-group-addon">
                                    <i class="fa fa-user-o" aria-hidden="true"></i>
                                </span>
                        <input id="usuario" type="text" class="form-control" name="usuario" placeholder="usuario" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                                <span class="input-group-addon">
                                    <i class="fa fa-key" aria-hidden="true"></i>

                                </span>
                        <input id="password" type="password" class="form-control" name="password" placeholder="Contraseña" />
                    </div>
                </div>
                <button id="login" type="submit" class="btn btn-default" >
                    ENTRAR<i class="glyphicon glyphicon-log-in"></i>
                </button>
            </div>
        </div>
        </form></div>
    </div>
</div>