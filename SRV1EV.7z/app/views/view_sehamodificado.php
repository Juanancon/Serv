<?php ?>

    <div class="alert alert-success" align="left">
        Ha modificado correctamente
    </div>

<?php ?>