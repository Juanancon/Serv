<?php ?>

    <div class="alert alert-success" align="left">
        Ha borrado correctamente
    </div>

<?php ?>