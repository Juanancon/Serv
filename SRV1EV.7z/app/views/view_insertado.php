<?php ?>

    <div class="alert alert-success" align="left">
        Ha añadido correctamente
    </div>

<?php ?>